
###This is a brief tutorial for using phrapl. This tutorial is embedded within an R script
###such that it can include executable code for prepping and analyzing an example dataset
###included within this directory. This tutorial walks through installation
###of phrapl and its dependencies, data preparation, analysis, and
###viewing of results. For more detailed information about certain aspects, see
###the help files within phrapl and the included manual.
###The included files used in this tutorial are

#Written by Nathan Jackson, May, 2015
#Modified by Brian O'Meara, June, 2015


############STEP1:Load and become aquainted with phrapl 
#Open R and load the phrapl library
library(phrapl)

#Open main help page
library(help=phrapl)

#Open help files for functions 
?GridSearch


############STEP2: Convert trees and assignments to r objects and specify popAssignments.
#If your estimated gene trees are in a text file in newick format,
#read them into R. An example tree file is included in this
#directory for you to use (called "trees.tre"). 

#Make sure you load the ape library
library(ape)

#You now have two options for the tutorial: load files from disk, as with a real run, or use the stored test files
#To do the loading, do the next three commands, otherwise, skip to USED_STORED_VALUES

trees<-read.tree("trees.tre")

#An assignment table must also be created which contains two columns:
#The first column lists the individuals in the dataset, whose names
#match those in the included trees. The second column gives the name of
#the population to which each individual is assigned. If there is
#an outgroup taxon, it should be included as the last population.
#A header row is also required.
#You can create this table in in R, or if your assignment table is in the 
#form of a text file, you can import it into R:

assignFile<-read.table("cladeAssignments.txt",header=TRUE,stringsAsFactors=FALSE) 

#Finally, popVector gives the number of individuals per population to be analyzed. 
#So if your trees have three individuals each from 3 populations, popVector = c(3,3,3).
#Note that because phrapl typically analyzes subsampled trees, popVector gives the number 
#of subsampled individuals per population.
#popAssignments is simply a list of popVectors, although typically, this list will consist
#of only one popVector. So, to analyze three populations with three tips each,

popAssignments<-list(c(3,3,3)) 

#USED_STORED_VALUES: not as useful as loading, but if something is not working:
data(TestData) #included with phrapl


############STEP3: Generate a model set
#A model analyzed by phrapl is called a "migrationIndividual", which contains
#matrices that define the coalescence, population size, and migration
#parameters included in that model. A set of models is called a migrationArray, 
#which is an R list of models. A migrationArray consisting of all possible models
#given certain constraints, such as the number of free parameters, K, available
#for a particular process or available overall, can be generated using the 
#GenerateMigrationIndividuals function. 
#For example, a list of models for three populations with 1) an overall maximum K of 3,
#2) a maximum number of migration parameters of 1, 3) no variation in population size
#among populations, 4) only fully resolved trees, and 4) migration set to be symmetrical 
#between populations can be generated as follows:

popVector<-popAssignments[[1]] #This gives the number of individuals in each population to b analyzed
maxK<-3 #maximum K
maxMigrationK=1 #maximum K for migration
maxN0K=1 #maximum number of population size scaling parameters
forceTree=TRUE #should only fully resolved trees be considered?
forceSymmetricalMigration=TRUE #Must migration be symmetrical?

migrationArray<-GenerateMigrationIndividuals(popVector=popVector,maxK=maxK,
	maxMigrationK=maxMigrationK,maxN0K=maxN0K,forceTree=forceTree,
	forceSymmetricalMigration=forceSymmetricalMigration)


############STEP4: Subsample trees
#The approximate likelihood calculation as currently implemented in phrapl requires trees that 
#are not too large - ~20 tips total is the most that you could have and still have any chance 
#of ever even seeing your observed tree in a distribution of simulated trees (which must happen 
#to some extent in order to estimate a likelihood). Since most phylogeographic datasets are 
#considerably larger than this, phrapl relies on analyzing replicate subsamples of the tree, 
#rather than the full tree all at once. We have found that subsampling ~3 or 4 tips per population
#works best, with enough replicates to ensure that you've on average sampled each individual a few
#times. 
#Trees should be rooted. If an outgroup is used to root trees, set 

outgroup=TRUE
outgroupPrune=TRUE

#These arguments will ensure that subsampled trees are rooted with the outgroup, and then
#the outgroup is pruned from the tree.

#To subsample the example dataset at 3 tips per population, with 10 replicates, do the following:

assignmentsGlobal<-assignFile #population assignments
observedTrees<-trees #original tree object
popAssignments<-popAssignments
subsamplesPerGene<-10 #number of replicate subsamples per locus

observedTrees<-PrepSubsampling(assignmentsGlobal=assignmentsGlobal,observedTrees<-observedTrees,
	popAssignments=popAssignments,subsamplesPerGene=subsamplesPerGene,outgroup=outgroup,
	outgroupPrune=outgroupPrune)
	
#Note that this produces a list of subsampled tree sets, one set per popVector. Thus, if you
#just have one popVector in your popAssignments, the observedTrees list with contain a single
#set of subsampled trees


############STEP5: Calculate degeneracy weights for subsampled trees
#More accurate estimates of log-likelihood can be obtained by weighting subsampled
#trees based on the degeneracy of tip labels (i.e., the proportion of times that permuting 
#labels across a tree results in the same topology).
#To calculate weights for subsampled trees, do the following:

subsampleWeights.df<-GetPermutationWeightsAcrossSubsamples(popAssignments=popAssignments,
	observedTrees=observedTrees)
	
#As with PrepSubsampling, this function produces a list of weights tables with the same length
#as popAssignments.


############STEP6: Run a phrapl grid search
#To calculate AIC values for a given dataset under a given set of models, use the GridSearch function.

modelRange<-1:3 #if you don't want to run the entire migrationArray, you can specify a range of models
nTrees<-1e3 #this gives the number of trees simulated per set of parameters. It should be set to 1e4 at a minimum.
print.results<-TRUE #print results to screen
return.all<-TRUE #give AIC and parameter estimates

result<-GridSearch(migrationArray=migrationArray,modelRange=modelRange,popAssignments=popAssignments,
	observedTrees=observedTrees,subsampleWeights.df=subsampleWeights.df,subsamplesPerGene=subsamplesPerGene,
	nTrees=nTrees,print.results=print.results,return.all=return.all)
    
#Save results to an R object file
save(list=ls(), file="phraplOutput.rda")

#GridSearch returns a list containing a 1) the parameter grid (with AICs) for each model, 2) an overall results
#table that gives model AIC, lnL, K, and the parameters in each model, 3) parameter estimates for each model, and 4)
#parameter indexes, which indicate whether a parameter is present (1) or absent (0) in each model.


############STEP7:Cull, print, and visualize results
#Use the following function to generate an output table for the analyzed models
#(which can concatenate results across many models analyzed in separate runs
totalData<-ConcatenateResults(rdaFiles="phraplOutput.rda")

#Calculate model averaged parameter values for the dataset
modelAverages<-CalculateModelAverages(totalData,parmStartCol=9)

#Plot a 3-D movie of the best model
PlotModel(migrationIndividual=migrationArray[[2]],taxonNames=c("A","B","C")) 
    