#!/bin/bash

##Shell script to compile ms (Hudson)

gcc -o ms ms.c streec.c rand1.c -lm

gcc -o sample_stats sample_stats.c tajd.c -lm