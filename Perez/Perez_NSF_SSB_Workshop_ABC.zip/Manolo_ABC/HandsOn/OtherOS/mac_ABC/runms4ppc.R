## Code that simulate data for the evolution2015 ABC course

## in order to use this code you have to have ms installed on your computer
## ms can be freely downloaded from:
## http://home.uchicago.edu/rhudson1/source/mksamples.html


### variable declarations

## sample sizes (number of alleles). For diploid data, multiply by 2.
Nsam = 93*2
## sample size of Pop1.
Pop1 = 73*2
## sample size of Pop2.
Pop2 = 20*2
## number of base pairs
L <- 400
## number of loci
numloc <- 25
## number of years per generation
genlen <- 30
## mean mutation rate for A. thaliana
mutrate <- 7*10^(-9)

## number of simulations for the posterior check
simpost<-100

## perform the abc for inferring the parameters
peNN<-abc(target=emp, param=parameters, sumstat=sust, tol=0.1, method="neuralnet", bounds=rbind(c(100,30000),c(300000, 4000000),c(0.01, 1),c(0.01, 1),c(0.1, 5),c(0.1, 5)))

## sampling with replacement in the multivariate posterior distribution
newsamp<-sample(1:(dim(peNN$adj)[1]),size=simpost,replace=T,prob=peNN$weights) 

newsamp<-peNN$adj[newsamp,]

## Theta in the right unit
thetapost <- newsamp[,1]*4*mutrate*L
## divergence times in the right unit
coalDivTimepost<-(newsamp[,2]/(genlen*4*newsamp[,1]))

ppc <- data.frame()

##Counter
linecounter = 1

for (i in 1:simpost) {

### Define parameters
theta <- thetapost[linecounter]
coalDivTime <- coalDivTimepost[linecounter]
RatioPop1 <- newsamp[linecounter,3]
RatioPop2 <- newsamp[linecounter,4]
Migration12<-newsamp[linecounter,5]
Migration21<-newsamp[linecounter,6]

## ms's command
system(sprintf("./ms %d %d -t %f -I 2 %f %f -n 1 %f -n 2 %f -m 1 2 %s -m 2 1 %s -ej %f 1 2 | ./sample_stats >> ppc.txt", Nsam, numloc, theta, Pop1, Pop2, RatioPop1, RatioPop2, Migration12, Migration21, coalDivTime))

linecounter <- linecounter +1
}

###Average the sum stats over the 25 loci
ppc <- read.table("ppc.txt")
ppc <- data.frame(pi.m=tapply(ppc[,2]/L, factor(rep(1:simpost, each=numloc)), mean,na.rm=T),
                  ss.m=tapply(ppc[,4], factor(rep(1:simpost, each=numloc)), mean,na.rm=T),
                  D.m=tapply(ppc[,6], factor(rep(1:simpost, each=numloc)), mean,na.rm=T),
                  T.m=tapply(ppc[,8], factor(rep(1:simpost, each=numloc)), mean,na.rm=T),
                  TH.m=tapply(ppc[,10], factor(rep(1:simpost, each=numloc)), mean,na.rm=T),
                  pi.v=tapply(ppc[,2]/L, factor(rep(1:simpost, each=numloc)), var,na.rm=T),
                  ss.v=tapply(ppc[,4], factor(rep(1:simpost, each=numloc)), var,na.rm=T),
                  D.v=tapply(ppc[,6], factor(rep(1:simpost, each=numloc)), var,na.rm=T))










## erase temporary files
system(sprintf("rm -rf ppc.txt"))