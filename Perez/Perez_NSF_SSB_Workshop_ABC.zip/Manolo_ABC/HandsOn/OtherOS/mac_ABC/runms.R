
## Code that simulate data for the evolution2015 ABC course

## in order to use this code you have to have ms installed on your computer
## ms can be freely downloaded from:
## http://home.uchicago.edu/rhudson1/source/mksamples.html


### variable declarations

## number of simulations
numsim <- 500
## sample sizes (number of alleles). For diploid data, multiply by 2.
Nsam = 93*2
## sample size of Pop1.
Pop1 = 73*2
## sample size of Pop2.
Pop2 = 20*2
## number of base pairs
L <- 400
## number of loci
numloc <- 25
## number of years per generation
genlen <- 30
## mean mutation rate for A. thaliana
mutrate <- 7*10^(-9)

### define default values for all parameters that are specific to a subset of the models
RatioPop1 <- 1
RatioPop2 <- 1
Migration12 <- 0
Migration21 <- 0
## create a variable to store all the parameters
parameters <- data.frame()

### constant pop size model

for (i in 1:numsim) {

### Define parameters
## Ne prior following a uniform distribution from 100 to 3000
Ne <- runif(1, 100, 30000)
## use Ne value to obtain the theta (required by ms)
theta <- Ne*4*mutrate*L
## divergence time prior following an uniform distribution from 300.000 to 4 million years ago
DivTime <- runif(1, 300000, 4000000)
## use the DivTime in years to calculte divergence time in colaescent units (required by ms)
coalDivTime <- DivTime/(genlen*4*Ne)

## ms's command
system(sprintf("./ms %d %d -t %f -I 2 %f %f -ej %f 1 2 | ./sample_stats >> const.txt", Nsam, numloc, theta, Pop1, Pop2, coalDivTime))

## save parameter values
parameters <- rbind(parameters, data.frame(Ne, DivTime, RatioPop1, RatioPop2, Migration12, Migration21))
}

## bottleneck in both pops model
for (i in 1:numsim) {

### Define parameters
Ne <- runif(1, 100, 30000)
theta <- Ne*4*mutrate*L
DivTime <- runif(1, 300000, 4000000)
coalDivTime <- DivTime/(genlen*4*Ne)
##Bottleneck intensity in each population, measured as a rate of the Ne in the original population. Prior sampled from an uniform distribution from 0.01 to 1.
RatioPop1 <- runif(1, 0.01, 1)
RatioPop2 <- runif(1, 0.01, 1)

## ms's command
system(sprintf("./ms %d %d -t %f -I 2 %f %f -n 1 %f -n 2 %f -ej %f 1 2 | ./sample_stats >> bott.txt", Nsam, numloc, theta, Pop1, Pop2, RatioPop1, RatioPop2, coalDivTime))

## save parameter values
parameters <- rbind(parameters, data.frame(Ne, DivTime, RatioPop1, RatioPop2, Migration12, Migration21))
}

## Bidirectional migration model
for (i in 1:numsim) {

### Define parameters
Ne <- runif(1, 100, 30000)
theta <- Ne*4*mutrate*L
DivTime <- runif(1, 300000, 4000000)
coalDivTime <- DivTime/(genlen*4*Ne)
## migration prior sampled sampled from an uniform distribution from 0.1 to 5 migrants per generation.
Migration12 <- runif(1, 0.1, 5)
Migration21 <- runif(1, 0.1, 5)

## ms's command
system(sprintf("./ms %d %d -t %f -I 2 %f %f -m 1 2 %f -m 2 1 %f -ej %f 1 2 | ./sample_stats >> migr.txt", Nsam, numloc, theta, Pop1, Pop2, Migration12, Migration21, coalDivTime))

## save parameter values
parameters <- rbind(parameters, data.frame(Ne, DivTime, RatioPop1, RatioPop2, Migration12, Migration21))
}

##sample_stats exports data in the following format: pi:	0.404999	ss:	1	D:	1.381008	thetaH:	0.157164	H:	0.247835
## calculate summary statistics mean and variance over the 25 loci
const <- read.table("const.txt")
const <- data.frame(pi.m=tapply(const[,2]/L, factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   ss.m=tapply(const[,4], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   D.m=tapply(const[,6], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   T.m=tapply(const[,8], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   TH.m=tapply(const[,10], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   pi.v=tapply(const[,2]/L, factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                   ss.v=tapply(const[,4], factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                   D.v=tapply(const[,6], factor(rep(1:numsim, each=numloc)), var,na.rm=T))
bott <- read.table("bott.txt")
bott <- data.frame(pi.m=tapply(bott[,2]/L, factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                  ss.m=tapply(bott[,4], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                  D.m=tapply(bott[,6], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                  T.m=tapply(bott[,8], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                  TH.m=tapply(bott[,10], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                  pi.v=tapply(bott[,2]/L, factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                  ss.v=tapply(bott[,4], factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                  D.v=tapply(bott[,6], factor(rep(1:numsim, each=numloc)), var,na.rm=T))
migr <- read.table("migr.txt")
migr <- data.frame(pi.m=tapply(migr[,2]/L, factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   ss.m=tapply(migr[,4], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   D.m=tapply(migr[,6], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   T.m=tapply(migr[,6], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   TH.m=tapply(migr[,6], factor(rep(1:numsim, each=numloc)), mean,na.rm=T),
                   pi.v=tapply(migr[,2]/L, factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                   ss.v=tapply(migr[,4], factor(rep(1:numsim, each=numloc)), var,na.rm=T),
                   D.v=tapply(migr[,6], factor(rep(1:numsim, each=numloc)), var,na.rm=T))

models <- rep(c("const", "bott", "migr"), each=numsim)

## join data
sust <- rbind(const, bott, migr)
names(sust) <- c("pi.m", "ss.m", "TajD.m", "T.m", "TH.m","pi.v", "ss.v","TajD.v")

##optional lines to save the files in the folder, not only in the R environment
##write.table(models, file="models.txt", quote=F, row.names=F, col.names=F)
##write.table(parameters, file="parameters.txt", quote=F, row.names=F, col.names=F)
##write.table(sust, file="sust.txt", quote=F, row.names=F, col.names=F)

## erase temporary files
##system(sprintf("rm -rf const.txt bott.txt migr.txt"))